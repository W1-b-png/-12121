@echo off
cd /d "%~dp0"
start "" "MousePet.exe" --follow
