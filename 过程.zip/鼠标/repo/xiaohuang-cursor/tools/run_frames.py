# -*- coding: utf-8 -*-
"""生成「跑动」帧：压扁 / 弹起 + 轻微倾斜，200px 画布，热点固定"""
import math
import os

import numpy as np
from PIL import Image, ImageFilter

import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import ASSETS, PNG, ANIM, CURSORS, BUILD, RUN, SPRITE, ICON
OUT = RUN
SPRITE = Image.open(SPRITE).convert("RGBA")

SS = 2
C = 256
INK = (52, 39, 23, 255)
HOT = (124, 56)


def rim(layer, px=2.6):
    a = layer.getchannel("A")
    k = max(3, int(px * SS * 2) | 1)
    under = Image.new("RGBA", layer.size, INK)
    under.putalpha(a.filter(ImageFilter.MaxFilter(k)))
    return Image.alpha_composite(under, layer)


def down(img):
    arr = np.asarray(img).astype(np.float32) / 255.0
    a = arr[..., 3:4]
    pre = np.dstack([arr[..., :3] * a, a])
    small = Image.fromarray((pre * 255).round().astype(np.uint8), "RGBA").resize((C, C), Image.LANCZOS)
    s = np.asarray(small).astype(np.float32) / 255.0
    sa = np.maximum(s[..., 3:4], 1e-6)
    out = np.dstack([np.clip(s[..., :3] / sa, 0, 1), s[..., 3:4]]) * 255
    return Image.fromarray(out.round().astype(np.uint8), "RGBA")


def frame(h=196, cx=128, bottom=250, kx=1.0, ky=1.0, angle=0.0, dy=0.0):
    w = h * SPRITE.width / SPRITE.height
    im = SPRITE.resize((max(1, round(w * SS)), max(1, round(h * SS))), Image.LANCZOS)
    im = im.resize((max(1, round(im.width * kx)), max(1, round(im.height * ky))), Image.LANCZOS)
    if angle:
        im = im.rotate(angle, resample=Image.BICUBIC, expand=True)
    lay = Image.new("RGBA", (C * SS, C * SS), (0, 0, 0, 0))
    x = round(cx * SS - im.width / 2)
    y = round((bottom + dy) * SS - im.height)
    lay.alpha_composite(im, (x, y))
    return down(rim(lay))


os.makedirs(OUT, exist_ok=True)

# 站立
frame().save(OUT + r"\idle.png")

# 小跑：压扁 -> 弹起偏左 -> 压扁 -> 弹起偏右
cycle = [
    dict(kx=1.06, ky=0.94, angle=0.0, dy=3),
    dict(kx=0.97, ky=1.05, angle=-4.0, dy=-4),
    dict(kx=1.06, ky=0.94, angle=0.0, dy=3),
    dict(kx=0.97, ky=1.05, angle=4.0, dy=-4),
]
for i, kw in enumerate(cycle):
    frame(**kw).save(f"{OUT}\\run{i}.png")

print("frames ->", OUT, "hotspot", HOT)

# 拼一张检查图
sheet = Image.new("RGB", (5 * 230 + 10, 250), (245, 245, 242))
for i, name in enumerate(["idle", "run0", "run1", "run2", "run3"]):
    im = Image.open(f"{OUT}\\{name}.png")
    cell = Image.new("RGB", (220, 220), (250, 250, 248))
    cell.paste(im, (0, 0), im)
    sheet.paste(cell, (10 + i * 230, 15))
sheet.save(WORK + r"\check_run.png")
