# -*- coding: utf-8 -*-
"""把所有状态帧打包成一个二进制资源（给 MousePet.exe 内嵌）"""
import io
import os
import struct

from PIL import Image

import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import ASSETS, PNG, ANIM, CURSORS, BUILD, RUN, SPRITE, ICON
OUT = os.path.join(BUILD, "frames.bin")

SIZE = 128          # 内嵌分辨率（屏幕上是 ~74px，留了余量）
os.makedirs(BUILD, exist_ok=True)

# 名称 -> (文件, 256 画布下的热点)
STATIC = {
    "arrow": (os.path.join(RUN, "idle.png"), (124, 56)),
    "ibeam": (PNG + r"\ibeam.png", (76, 96)),
    "hand": (PNG + r"\hand.png", (59, 46)),
    "no": (PNG + r"\no.png", (128, 112)),
    "crosshair": (PNG + r"\crosshair.png", (86, 96)),
    "sizens": (PNG + r"\sizens.png", (128, 128)),
    "sizewe": (PNG + r"\sizewe.png", (128, 128)),
    "sizenwse": (PNG + r"\sizenwse.png", (128, 128)),
    "sizenesw": (PNG + r"\sizenesw.png", (128, 128)),
    "sizeall": (PNG + r"\sizeall.png", (128, 128)),
    "uparrow": (PNG + r"\uparrow.png", (66, 26)),
    "nwpen": (PNG + r"\nwpen.png", (40, 40)),
    "help": (PNG + r"\help.png", (120, 56)),
    "pin": (PNG + r"\pin.png", (62, 152)),
    "person": (PNG + r"\person.png", (62, 64)),
}

frames = []           # (name, hotx, hoty, png_bytes)

for i in range(4):
    frames.append(("run%d" % i, 124, 56, os.path.join(RUN, "run%d.png" % i)))

for name, (path, hot) in STATIC.items():
    frames.append((name, hot[0], hot[1], path))

for i in range(6):
    frames.append(("wait%d" % i, 120, 56, os.path.join(ANIM, "wait_f%02d.png" % i)))

for i in range(12):
    frames.append(("app%d" % i, 120, 56, os.path.join(ANIM, "appstarting_f%02d.png" % i)))

out = io.BytesIO()
out.write(struct.pack("<I", len(frames)))
for name, hx, hy, path in frames:
    im = Image.open(path).convert("RGBA").resize((SIZE, SIZE), Image.LANCZOS)
    buf = io.BytesIO()
    im.save(buf, "PNG", optimize=True)
    data = buf.getvalue()
    nm = name.encode("ascii")
    out.write(struct.pack("<I", len(nm)))
    out.write(nm)
    out.write(struct.pack("<ii", round(hx * SIZE / 256), round(hy * SIZE / 256)))
    out.write(struct.pack("<I", len(data)))
    out.write(data)

open(OUT, "wb").write(out.getvalue())
print("frames:", len(frames), "->", OUT, len(out.getvalue()) // 1024, "KB")
