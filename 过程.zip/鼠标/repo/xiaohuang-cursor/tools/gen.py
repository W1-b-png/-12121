# -*- coding: utf-8 -*-
"""角色化鼠标指针生成器：把小黄团子做成 17 个指针状态（256px，透明，深色描边）"""
import math
import os

import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import ASSETS, PNG, ANIM, CURSORS, BUILD, RUN, SPRITE, ICON
OUT = PNG
WORK = ASSETS

SS = 2                      # 超采样倍率（512 画布 -> 256 输出）
C = 256
INK = (52, 39, 23, 255)     # 描边：深棕
WHITE = (255, 255, 255, 255)
YELLOW = (247, 202, 88, 255)

SPRITE = Image.open(SPRITE).convert("RGBA")
EYES = [(0.324, 0.168), (0.712, 0.168)]   # 眼睛中心的相对坐标


# ---------------------------------------------------------------- 基础工具
def new_layer():
    return Image.new("RGBA", (C * SS, C * SS), (0, 0, 0, 0))


def char(h, cx, bottom, angle=0.0, kx=1.0, ky=1.0):
    """把角色放到高 h（256 坐标系）、水平中心 cx、底边 bottom 的位置"""
    w = h * SPRITE.width / SPRITE.height
    im = SPRITE.resize((max(1, round(w * SS)), max(1, round(h * SS))), Image.LANCZOS)
    if kx != 1.0 or ky != 1.0:
        im = im.resize((max(1, round(im.width * kx)), max(1, round(im.height * ky))),
                       Image.LANCZOS)
    if angle:
        im = im.rotate(angle, resample=Image.BICUBIC, expand=True)
    x = round(cx * SS - im.width / 2)
    y = round(bottom * SS - im.height)
    return im, (x, y)


def rim(layer, px=3.0):
    """给图层加一圈深色描边（按 alpha 膨胀）"""
    a = layer.getchannel("A")
    k = max(3, int(px * SS * 2) | 1)
    d = a.filter(ImageFilter.MaxFilter(k))
    under = Image.new("RGBA", layer.size, INK)
    under.putalpha(d)
    return Image.alpha_composite(under, layer)


def down(img):
    """预乘后缩小，避免半透明边缘发黑"""
    arr = np.asarray(img).astype(np.float32) / 255.0
    a = arr[..., 3:4]
    pre = np.dstack([arr[..., :3] * a, a])
    small = Image.fromarray((pre * 255).round().astype(np.uint8), "RGBA").resize(
        (C, C), Image.LANCZOS)
    s = np.asarray(small).astype(np.float32) / 255.0
    sa = np.maximum(s[..., 3:4], 1e-6)
    rgb = np.clip(s[..., :3] / sa, 0, 1)
    out = np.dstack([rgb, s[..., 3:4]]) * 255.0
    return Image.fromarray(out.round().astype(np.uint8), "RGBA")


def S(v):
    return v * SS


# ---------------------------------------------------------------- 图形元件
def tri(d, tip, ang, length, halfw, fill=WHITE):
    a = math.radians(ang)
    ux, uy = math.cos(a), math.sin(a)
    bx, by = tip[0] - ux * length, tip[1] - uy * length
    px, py = -uy, ux
    pts = [(S(tip[0]), S(tip[1])),
           (S(bx + px * halfw), S(by + py * halfw)),
           (S(bx - px * halfw), S(by - py * halfw))]
    d.polygon(pts, fill=fill)


def bubble(canvas, box, r, fill=WHITE, tail=None):
    lay = new_layer()
    d = ImageDraw.Draw(lay)
    x0, y0, x1, y1 = [S(v) for v in box]
    d.rounded_rectangle([x0, y0, x1, y1], radius=S(r), fill=fill)
    for (cx, cy, rr) in (tail or []):
        d.ellipse([S(cx - rr), S(cy - rr), S(cx + rr), S(cy + rr)], fill=fill)
    canvas.alpha_composite(rim(lay))


def glyph_layer():
    lay = new_layer()
    return lay, ImageDraw.Draw(lay)


def push(canvas, lay):
    canvas.alpha_composite(rim(lay))


def spinner(canvas, cx, cy, r, start, w=8):
    lay = new_layer()
    d = ImageDraw.Draw(lay)
    d.arc([S(cx - r), S(cy - r), S(cx + r), S(cy + r)], start=start, end=start + 280,
          fill=WHITE, width=int(S(w)))
    a = math.radians(start + 280)
    hx, hy = cx + r * math.cos(a), cy + r * math.sin(a)
    d.ellipse([S(hx - w * 0.62), S(hy - w * 0.62), S(hx + w * 0.62), S(hy + w * 0.62)], fill=WHITE)
    push(canvas, lay)


def crosshair(canvas, cx, cy, size=94, gap=0):
    lay, d = glyph_layer()
    d.line([S(cx - size), S(cy), S(cx - gap), S(cy)], fill=WHITE, width=int(S(6)))
    d.line([S(cx + gap), S(cy), S(cx + size), S(cy)], fill=WHITE, width=int(S(6)))
    d.line([S(cx), S(cy - size), S(cx), S(cy - gap)], fill=WHITE, width=int(S(6)))
    d.line([S(cx), S(cy + gap), S(cx), S(cy + size)], fill=WHITE, width=int(S(6)))
    d.ellipse([S(cx - 26), S(cy - 26), S(cx + 26), S(cy + 26)], outline=WHITE, width=int(S(5)))
    push(canvas, lay)


def ibeam(canvas, cx, cy, h=176):
    lay, d = glyph_layer()
    stem_w, bar_w = 11, 62
    d.rounded_rectangle([S(cx - stem_w / 2), S(cy - h / 2), S(cx + stem_w / 2), S(cy + h / 2)],
                        radius=S(stem_w / 2), fill=WHITE)
    for yy in (cy - h / 2 + 7, cy + h / 2 - 7):
        d.rounded_rectangle([S(cx - bar_w / 2), S(yy - 7), S(cx + bar_w / 2), S(yy + 7)],
                            radius=S(7), fill=WHITE)
    push(canvas, lay)


def pencil(canvas, tip, ang=45, length=150):
    """铅笔：笔尖在 tip，ang 是「从笔尖指向笔尾」的角度"""
    a = math.radians(ang)
    ux, uy = math.cos(a), math.sin(a)
    px, py = -uy, ux

    def pt(along, side):
        return (S(tip[0] + ux * along + px * side), S(tip[1] + uy * along + py * side))

    lay, d = glyph_layer()
    d.polygon([pt(0, 0), pt(30, -16), pt(30, 16)], fill=(247, 231, 199, 255))          # 木尖
    d.polygon([pt(28, -16), pt(length, -16), pt(length, 16), pt(28, 16)], fill=YELLOW)  # 笔杆
    push(canvas, lay)

    lay2, d2 = glyph_layer()                                            # 橡皮 + 铅芯
    d2.polygon([pt(length - 15, -16), pt(length, -16), pt(length, 16), pt(length - 15, 16)],
               fill=(240, 168, 138, 255))
    d2.polygon([pt(0, 0), pt(10, -6), pt(10, 6)], fill=INK)
    canvas.alpha_composite(lay2)


def hand(canvas, cx=66, cy=108, s=1.0):
    lay, d = glyph_layer()
    d.ellipse([S(cx - 27 * s), S(cy - 8 * s), S(cx + 27 * s), S(cy + 48 * s)], fill=WHITE)   # 手掌
    d.line([S(cx), S(cy + 14 * s), S(cx - 7 * s), S(cy - 48 * s)],
           fill=WHITE, width=int(S(25 * s)))                                                 # 食指
    d.ellipse([S(cx - 19 * s), S(cy - 60 * s), S(cx + 5 * s), S(cy - 36 * s)], fill=WHITE)   # 圆指尖
    d.line([S(cx - 16 * s), S(cy + 6 * s), S(cx - 34 * s), S(cy - 16 * s)],
           fill=WHITE, width=int(S(20 * s)))                                                 # 拇指
    push(canvas, lay)


def pin_glyph(canvas, cx=64, cy=58, s=1.0):
    lay, d = glyph_layer()
    d.ellipse([S(cx - 30 * s), S(cy - 30 * s), S(cx + 30 * s), S(cy + 30 * s)], fill=WHITE)
    d.polygon([(S(cx - 26 * s), S(cy + 16 * s)), (S(cx + 26 * s), S(cy + 16 * s)),
               (S(cx), S(cy + 94 * s))], fill=WHITE)
    push(canvas, lay)
    lay2, d2 = glyph_layer()
    d2.ellipse([S(cx - 11 * s), S(cy - 11 * s), S(cx + 11 * s), S(cy + 11 * s)], fill=INK)
    canvas.alpha_composite(lay2)


def person_glyph(canvas, cx=64, cy=66, s=1.0):
    lay, d = glyph_layer()
    d.ellipse([S(cx - 36 * s), S(cy - 36 * s), S(cx + 36 * s), S(cy + 36 * s)], fill=WHITE)
    push(canvas, lay)

    circle = Image.new("L", (C * SS, C * SS), 0)
    ImageDraw.Draw(circle).ellipse([S(cx - 35 * s), S(cy - 35 * s), S(cx + 35 * s), S(cy + 35 * s)],
                                   fill=255)
    sil = Image.new("L", (C * SS, C * SS), 0)
    sd = ImageDraw.Draw(sil)
    sd.ellipse([S(cx - 12 * s), S(cy - 23 * s), S(cx + 12 * s), S(cy + 1 * s)], fill=255)
    sd.ellipse([S(cx - 23 * s), S(cy + 5 * s), S(cx + 23 * s), S(cy + 46 * s)], fill=255)
    sil = Image.composite(sil, Image.new("L", sil.size, 0), circle)
    ink = Image.new("RGBA", (C * SS, C * SS), INK)
    ink.putalpha(sil)
    canvas.alpha_composite(ink)


def up_arrow(canvas, cx=64, cy=100, s=1.0):
    lay, d = glyph_layer()
    d.rounded_rectangle([S(cx - 9 * s), S(cy - 40 * s), S(cx + 9 * s), S(cy + 46 * s)],
                        radius=S(9 * s), fill=WHITE)
    tri(d, (cx, cy - 92 * s), -90, 56 * s, 34 * s, fill=WHITE)
    push(canvas, lay)


def question_bubble(canvas, box, tail, size):
    bubble(canvas, box, 20, tail=tail)
    lay = Image.new("RGBA", (C * SS, C * SS), (0, 0, 0, 0))
    d = ImageDraw.Draw(lay)
    try:
        font = ImageFont.truetype("C:/Windows/Fonts/segoeuib.ttf", int(S(size)))
    except OSError:
        font = ImageFont.load_default()
    x0, y0, x1, y1 = box
    d.text((S((x0 + x1) / 2), S((y0 + y1) / 2)), "?", font=font, fill=INK, anchor="mm")
    canvas.alpha_composite(lay)


# ---------------------------------------------------------------- 状态合成
def fill_notch(layer, y_frac=0.76, color=(196, 137, 56, 255)):
    """把两腿之间的小缝填成暗黄色，避免缩到 32px 时出现一个亮缝"""
    arr = np.asarray(layer).copy()
    a = arr[..., 3]
    h, w = a.shape
    for y in range(int(h * y_frac), h):
        idx = np.nonzero(a[y] > 10)[0]
        if idx.size < 2:
            continue
        runs, start = [], idx[0]
        for i in range(1, idx.size):
            if idx[i] != idx[i - 1] + 1:
                runs.append((start, idx[i - 1]))
                start = idx[i]
        runs.append((start, idx[-1]))
        if len(runs) >= 2:
            left, right = runs[0][1], runs[-1][0]
            if right - left > 2:
                arr[y, left + 1:right, :] = color
    return Image.fromarray(arr, "RGBA")


def base_char(h=196, cx=128, bottom=250, angle=0.0, kx=1.0, ky=1.0):
    lay = new_layer()
    im, xy = char(h, cx, bottom, angle, kx, ky)
    lay.alpha_composite(im, xy)
    return lay


def eyes_pos(h, cx, bottom, kx=1.0, ky=1.0):
    w = h * SPRITE.width / SPRITE.height * kx
    hh = h * ky
    x0 = cx - w / 2
    y0 = bottom - hh
    return [(x0 + ex * w, y0 + ey * hh) for ex, ey in EYES], w


def st_arrow():
    c = new_layer()
    c.alpha_composite(rim(base_char()))
    return c


def st_wait(dots=3):
    c = new_layer()
    c.alpha_composite(rim(base_char(h=188, cx=104, bottom=252)))
    bubble(c, (150, 6, 248, 74), 22)
    lay = Image.new("RGBA", (C * SS, C * SS), (0, 0, 0, 0))
    d = ImageDraw.Draw(lay)
    for i in range(dots):
        x = 178 + i * 21
        d.ellipse([S(x - 6), S(34), S(x + 6), S(46)], fill=INK)
    c.alpha_composite(lay)
    return c


def st_appstarting(angle=0):
    c = new_layer()
    c.alpha_composite(rim(base_char(h=186, cx=118, bottom=252)))
    spinner(c, 48, 190, 26, angle)
    return c


def st_help():
    c = new_layer()
    c.alpha_composite(rim(base_char(h=188, cx=116, bottom=252)))
    question_bubble(c, (150, 10, 240, 92), [(142, 100, 7), (128, 112, 4)], 62)
    return c


def st_crosshair():
    c = new_layer()
    c.alpha_composite(rim(base_char(h=146, cx=196, bottom=250)))
    crosshair(c, 86, 96, size=80)
    return c


def st_ibeam():
    c = new_layer()
    c.alpha_composite(rim(base_char(h=146, cx=196, bottom=250)))
    ibeam(c, 76, 96)
    return c


def st_nwpen():
    c = new_layer()
    c.alpha_composite(rim(base_char(h=150, cx=196, bottom=250)))
    pencil(c, (40, 40), ang=44, length=168)
    return c


def st_no():
    c = new_layer()
    c.alpha_composite(rim(base_char(h=200, cx=128, bottom=252)))
    pts, w = eyes_pos(200, 128, 252)
    r = w * 0.105
    lay, d = glyph_layer()
    for (ex, ey) in pts:
        d.line([S(ex - r), S(ey - r), S(ex + r), S(ey + r)], fill=INK, width=int(S(9)))
        d.line([S(ex - r), S(ey + r), S(ex + r), S(ey - r)], fill=INK, width=int(S(9)))
    c.alpha_composite(lay)
    return c


def blob_arrow(axis="v"):
    """把角色压扁 + 两端箭头，做成 Windows 的 resize 光标"""
    inner = new_layer()
    if axis == "v":
        inner.alpha_composite(rim(base_char(h=176, cx=128, bottom=216, kx=0.52), 2.2))
        lay, d = glyph_layer()
        tri(d, (128, 8), -90, 66, 42, fill=YELLOW)
        tri(d, (128, 248), 90, 66, 42, fill=YELLOW)
        inner.alpha_composite(rim(lay, 2.2))
    else:
        inner.alpha_composite(rim(base_char(h=200, cx=128, bottom=183, ky=0.55), 2.2))
        lay, d = glyph_layer()
        tri(d, (8, 128), 180, 66, 42, fill=YELLOW)
        tri(d, (248, 128), 0, 66, 42, fill=YELLOW)
        inner.alpha_composite(rim(lay, 2.2))
    return inner


def st_resize(angle=0):
    inner = blob_arrow("v")
    if not angle:
        return inner
    rot = inner.rotate(angle, resample=Image.BICUBIC, expand=True)
    canvas = new_layer()
    lim = C * SS
    if max(rot.size) > lim:
        f = lim / max(rot.size)
        rot = rot.resize((round(rot.width * f), round(rot.height * f)), Image.LANCZOS)
    canvas.alpha_composite(rot, ((lim - rot.width) // 2, (lim - rot.height) // 2))
    return canvas


def st_sizeall():
    c = new_layer()
    lay, d = glyph_layer()
    d.rounded_rectangle([S(115), S(40), S(141), S(216)], radius=S(13), fill=WHITE)
    d.rounded_rectangle([S(40), S(115), S(216), S(141)], radius=S(13), fill=WHITE)
    for ang, (x, y) in [(-90, (128, 18)), (90, (128, 238)), (180, (18, 128)), (0, (238, 128))]:
        tri(d, (x, y), ang, 46, 27, fill=WHITE)
    c.alpha_composite(rim(lay, 3.0))
    c.alpha_composite(rim(base_char(h=130, cx=128, bottom=200)))
    return c


def st_uparrow():
    c = new_layer()
    c.alpha_composite(rim(base_char(h=146, cx=196, bottom=250)))
    up_arrow(c, 66, 96, 1.0)
    return c


def st_hand():
    c = new_layer()
    c.alpha_composite(rim(base_char(h=150, cx=192, bottom=250)))
    hand(c, 62, 86, 0.95)
    return c


def st_pin():
    c = new_layer()
    c.alpha_composite(rim(base_char(h=146, cx=198, bottom=250)))
    pin_glyph(c, 62, 62, 1.0)
    return c


def st_person():
    c = new_layer()
    c.alpha_composite(rim(base_char(h=146, cx=198, bottom=250)))
    person_glyph(c, 62, 64, 0.95)
    return c


STATES = {
    "arrow": (st_arrow, (124, 56)),
    "help": (st_help, (120, 56)),
    "appstarting": (lambda: st_appstarting(0), (120, 56)),
    "wait": (lambda: st_wait(3), (120, 56)),
    "crosshair": (st_crosshair, (86, 96)),
    "ibeam": (st_ibeam, (76, 96)),
    "nwpen": (st_nwpen, (46, 46)),
    "no": (st_no, (128, 112)),
    "sizens": (lambda: st_resize(0), (128, 128)),
    "sizewe": (lambda: st_resize(90), (128, 128)),
    "sizenwse": (lambda: st_resize(-45), (128, 128)),
    "sizenesw": (lambda: st_resize(45), (128, 128)),
    "sizeall": (st_sizeall, (128, 128)),
    "uparrow": (st_uparrow, (66, 26)),
    "hand": (st_hand, (59, 46)),
    "pin": (st_pin, (62, 152)),
    "person": (st_person, (62, 64)),
}


def main():
    os.makedirs(OUT, exist_ok=True)
    os.makedirs(BUILD, exist_ok=True)
    for name, (fn, hot) in STATES.items():
        c = fn()
        img = down(c)
        img.save(f"{OUT}\\{name}.png")
        print(f"{name:12s} hotspot={hot}")

    # 预览表
    import json
    json.dump({k: v[1] for k, v in STATES.items()}, open(os.path.join(BUILD, "hotspots.json"), "w"), indent=1)


if __name__ == "__main__":
    main()
