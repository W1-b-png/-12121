# -*- coding: utf-8 -*-
"""生成两个动画指针的帧序列"""
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import gen                                   # noqa: E402

OUT = gen.OUT

# 忙 = 思考：气泡里的点一个一个冒出来
for i, dots in enumerate([1, 2, 3, 3, 2, 1]):
    gen.down(gen.st_wait(dots)).save(f"{OUT}\\wait_f{i:02d}.png")

# 后台运行 = 转圈
for i in range(12):
    gen.down(gen.st_appstarting(i * 30)).save(f"{OUT}\\appstarting_f{i:02d}.png")

print("frames ok")
