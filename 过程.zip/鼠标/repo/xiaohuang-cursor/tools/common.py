# -*- coding: utf-8 -*-
"""仓库内的统一路径（所有脚本都从这里取）"""
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TOOLS = os.path.join(ROOT, "tools")
ASSETS = os.path.join(ROOT, "assets")
PNG = os.path.join(ROOT, "png")
ANIM = os.path.join(PNG, "动画帧")
CURSORS = os.path.join(ROOT, "cursors")
BUILD = os.path.join(ROOT, "build")
RUN = os.path.join(ASSETS, "run-frames")
SPRITE = os.path.join(ASSETS, "sprite.png")
ICON = os.path.join(ASSETS, "app.ico")
