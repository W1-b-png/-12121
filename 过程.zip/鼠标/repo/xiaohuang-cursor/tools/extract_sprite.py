# -*- coding: utf-8 -*-
"""从白底渲染图里把角色抠出来，输出带 alpha 的 sprite.png"""
import numpy as np
from PIL import Image, ImageFilter

SRC = r"C:\Users\LENOVO\.dsh\attachments\v1\objects\72\720c2b61ea132788a53124d5b4aee9114cd143c1a828fab95286c79b083eb604"
OUT = r"C:\Users\LENOVO\Desktop\鼠标\work"


def flood(allowed, seed=(0, 0)):
    """在 allowed 区域里做扫描线泛洪"""
    h, w = allowed.shape
    out = np.zeros_like(allowed)
    stack = [seed]
    while stack:
        x, y = stack.pop()
        if out[y, x] or not allowed[y, x]:
            continue
        xl = x
        while xl > 0 and not out[y, xl - 1] and allowed[y, xl - 1]:
            xl -= 1
        xr = x
        while xr < w - 1 and not out[y, xr + 1] and allowed[y, xr + 1]:
            xr += 1
        out[y, xl:xr + 1] = True
        for yy in (y - 1, y + 1):
            if 0 <= yy < h:
                seg = allowed[yy, xl:xr + 1] & ~out[yy, xl:xr + 1]
                idx = np.nonzero(seg)[0]
                if idx.size:
                    for run in np.split(idx, np.where(np.diff(idx) != 1)[0] + 1):
                        stack.append((xl + int(run[0]), yy))
    return out


rgb = Image.open(SRC).convert("RGB")
arr = np.asarray(rgb).astype(np.float32)
r, g, b = arr[..., 0], arr[..., 1], arr[..., 2]
mx, mn = arr.max(2), arr.min(2)
sat = (mx - mn) / np.maximum(mx, 1.0)
lum = 0.299 * r + 0.587 * g + 0.114 * b
h_, w_ = lum.shape

# 角色是饱和黄色 + 深色眼睛；背景白/灰 + 地面阴影都是低饱和度
subject = (sat > 0.32) | (lum < 100)

# 外部背景 = 从左上角能走到的非角色区域；走不到的空洞（高光）算角色
outside = flood(~subject)

# 两脚之间的地面阴影：从底边中间往上泛洪，判定为「低饱和 + 接近地面色」
seed = arr[h_ - 3, w_ // 2]
dist = np.sqrt(((arr - seed) ** 2).sum(2))
floor = (sat < 0.72) & (dist < 95)
zone = np.zeros_like(subject)
zone[int(h_ * 0.78):, :] = True          # 只处理底部区域，别顺着高光吃掉轮廓
floor &= zone
floor_region = floor                     # 直接按颜色判定，不需要再泛洪

alpha = (~outside).astype(np.uint8) * 255
alpha[floor_region] = 0

alpha_img = Image.fromarray(alpha, "L").filter(ImageFilter.GaussianBlur(1.2))
a = np.asarray(alpha_img).astype(np.float32) / 255.0
a3 = a[..., None]
# 反预乘：去掉边缘混进来的白底，避免深色背景上出现白边
clean = np.where(a3 > 0.02, (arr - 255.0 * (1.0 - a3)) / np.maximum(a3, 1e-6), arr)
clean = np.clip(clean, 0, 255)

rgba = np.dstack([clean, a * 255.0]).astype(np.uint8)
img = Image.fromarray(rgba, "RGBA")

bbox = alpha_img.getbbox()
img = img.crop(bbox)
img = img.crop((0, 0, img.width, img.height - 4))   # 去掉最底的接触阴影
img.save(OUT + r"\sprite.png")
print("sprite:", img.size, "bbox:", bbox)
