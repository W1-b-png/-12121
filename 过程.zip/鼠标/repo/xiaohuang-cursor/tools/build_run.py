# -*- coding: utf-8 -*-
"""把跑动帧打成 arrows_run.ani（不想开程序时的折中方案）"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from build import build_ani            # noqa: E402

import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import ASSETS, PNG, ANIM, CURSORS, BUILD, RUN, SPRITE, ICON
FR = RUN
OUT = os.path.join(CURSORS, "arrow_run.ani")

frames = [os.path.join(FR, "run%d.png" % i) for i in range(4)]
data = build_ani(frames, (110, 40), size=96, jiffies=5)   # 220 画布，96px 帧，12fps
open(OUT, "wb").write(data)
print("arrow_run.ani", len(frames), "帧", len(data) // 1024, "KB")
