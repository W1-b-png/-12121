﻿# 构建 MousePet.exe 和安装包（只需要 Windows 自带的 .NET Framework 编译器，不用装任何 SDK）
$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$csc  = Join-Path $env:WINDIR "Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if (-not (Test-Path $csc)) { throw "找不到 csc.exe，需要 .NET Framework 4.x" }

$out    = Join-Path $root "build"
$icon   = Join-Path $root "assets\app.ico"
$frames = Join-Path $root "assets\frames.bin"
New-Item -ItemType Directory -Force $out | Out-Null

& $csc /nologo /target:winexe /out:"$out\MousePet.exe" /win32icon:"$icon" `
    /r:System.dll /r:System.Drawing.dll /r:System.Windows.Forms.dll `
    /resource:"$frames",frames.bin /resource:"$icon",app.ico "$root\src\MousePet.cs"
if ($LASTEXITCODE -ne 0) { throw "MousePet 编译失败" }

& $csc /nologo /target:winexe /out:"$out\Setup.exe" /win32icon:"$icon" `
    /r:System.dll /r:System.Drawing.dll /r:System.Windows.Forms.dll `
    /resource:"$out\MousePet.exe",MousePet.exe "$root\src\Setup.cs"
if ($LASTEXITCODE -ne 0) { throw "安装包编译失败" }

Write-Host "构建完成："
Write-Host "  $out\MousePet.exe"
Write-Host "  $out\Setup.exe"
