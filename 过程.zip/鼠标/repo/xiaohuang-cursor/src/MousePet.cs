using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Win32;
using Timer = System.Windows.Forms.Timer;

// 小黄团子光标 —— 跟随鼠标的透明覆盖层
// 鼠标移动时播放小跑，停下站住；可托盘切换「替换 / 跟随」，可开机自启。

static class Nat
{
    [StructLayout(LayoutKind.Sequential)] public struct POINT { public int X; public int Y; }
    [StructLayout(LayoutKind.Sequential)] public struct SIZE { public int cx; public int cy; }
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct BLENDFUNCTION { public byte BlendOp; public byte BlendFlags; public byte SourceConstantAlpha; public byte AlphaFormat; }

    [StructLayout(LayoutKind.Sequential)]
    public struct BITMAPINFOHEADER
    {
        public uint biSize; public int biWidth; public int biHeight;
        public ushort biPlanes; public ushort biBitCount;
        public uint biCompression; public uint biSizeImage;
        public int biXPelsPerMeter; public int biYPelsPerMeter;
        public uint biClrUsed; public uint biClrImportant;
    }

    [DllImport("user32.dll")] public static extern bool GetCursorPos(out POINT p);
    [DllImport("user32.dll")] public static extern int ShowCursor(bool bShow);
    [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
    [DllImport("user32.dll")] public static extern int GetSystemMetrics(int index);
    [DllImport("user32.dll")] public static extern IntPtr GetDC(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern int ReleaseDC(IntPtr hWnd, IntPtr hDC);
    [DllImport("gdi32.dll")] public static extern IntPtr CreateCompatibleDC(IntPtr hdc);
    [DllImport("gdi32.dll")] public static extern bool DeleteDC(IntPtr hdc);
    [DllImport("gdi32.dll")] public static extern IntPtr SelectObject(IntPtr hdc, IntPtr obj);
    [DllImport("gdi32.dll")] public static extern bool DeleteObject(IntPtr obj);
    [DllImport("gdi32.dll")]
    public static extern IntPtr CreateDIBSection(IntPtr hdc, ref BITMAPINFOHEADER bmi, uint usage,
        out IntPtr bits, IntPtr hSection, uint offset);
    [DllImport("user32.dll")]
    public static extern bool UpdateLayeredWindow(IntPtr hwnd, IntPtr hdcDst, ref POINT pptDst,
        ref SIZE psize, IntPtr hdcSrc, ref POINT pptSrc, int crKey, ref BLENDFUNCTION pblend, int dwFlags);

    [StructLayout(LayoutKind.Sequential)] public struct CURSORINFO { public int cbSize; public int flags; public IntPtr hCursor; public int x; public int y; }

    [DllImport("user32.dll")] public static extern bool GetCursorInfo(ref CURSORINFO pci);
    [DllImport("user32.dll")] public static extern IntPtr LoadCursor(IntPtr hInstance, IntPtr lpCursorName);
    [DllImport("user32.dll")] public static extern IntPtr CreateCursor(IntPtr hInst, int xHot, int yHot, int w, int h, byte[] andPlane, byte[] xorPlane);
    [DllImport("user32.dll")] public static extern IntPtr LoadImage(IntPtr hinst, string name, uint type, int cx, int cy, uint flags);
    [DllImport("user32.dll", SetLastError = true)] public static extern bool SetSystemCursor(IntPtr hcur, uint id);
    [DllImport("user32.dll")] public static extern IntPtr CopyIcon(IntPtr hIcon);
    [DllImport("user32.dll")] public static extern bool DestroyCursor(IntPtr hIcon);
    [DllImport("user32.dll")] public static extern bool SystemParametersInfo(uint uiAction, uint uiParam, IntPtr pvParam, uint fWinIni);

    public const int ULW_ALPHA = 2;
    public const byte AC_SRC_ALPHA = 1;
    public const int SM_CXCURSOR = 13;
}

static class Settings
{
    const string Key = @"Software\XiaoHuangPet";
    const string RunKey = @"Software\Microsoft\Windows\CurrentVersion\Run";
    const string RunName = "XiaoHuangPet";

    public static string Mode
    {
        get
        {
            try
            {
                using (RegistryKey k = Registry.CurrentUser.OpenSubKey(Key))
                {
                    if (k == null) return "replace";
                    string v = k.GetValue("Mode") as string;
                    return v == "follow" ? "follow" : "replace";
                }
            }
            catch { return "replace"; }
        }
        set
        {
            try
            {
                using (RegistryKey k = Registry.CurrentUser.CreateSubKey(Key))
                    if (k != null) k.SetValue("Mode", value);
            }
            catch { }
        }
    }

    public static bool AutoStart
    {
        get
        {
            try
            {
                using (RegistryKey k = Registry.CurrentUser.OpenSubKey(RunKey))
                    return k != null && k.GetValue(RunName) != null;
            }
            catch { return false; }
        }
    }

    public static bool SetAutoStart(bool on, string exePath)
    {
        try
        {
            using (RegistryKey k = Registry.CurrentUser.OpenSubKey(RunKey, true))
            {
                if (k == null) return false;
                if (on) k.SetValue(RunName, "\"" + exePath + "\" --auto");
                else if (k.GetValue(RunName) != null) k.DeleteValue(RunName, false);
            }
            return true;
        }
        catch { return false; }
    }
}

// 这一块会被拼进 MousePet.cs：状态帧表 + 系统光标类型识别 + 覆盖层

class Frame
{
    public byte[] Data;      // 预乘后的 BGRA，已缩放到窗口尺寸
    public int HotX, HotY;   // 缩放后的热点
}

static class CursorKind
{
    const uint IDC_ARROW = 32512, IDC_IBEAM = 32513, IDC_WAIT = 32514, IDC_CROSS = 32515,
               IDC_UPARROW = 32516, IDC_SIZENWSE = 32642, IDC_SIZENESW = 32643,
               IDC_SIZEWE = 32644, IDC_SIZENS = 32645, IDC_SIZEALL = 32646,
               IDC_NO = 32648, IDC_HAND = 32649, IDC_APPSTARTING = 32650,
               IDC_HELP = 32651, IDC_PEN = 32631;

    static readonly uint[] Ids = { IDC_ARROW, IDC_IBEAM, IDC_WAIT, IDC_CROSS, IDC_UPARROW,
                                   IDC_SIZENWSE, IDC_SIZENESW, IDC_SIZEWE, IDC_SIZENS, IDC_SIZEALL,
                                   IDC_NO, IDC_HAND, IDC_APPSTARTING, IDC_HELP, IDC_PEN };

    static readonly string[] Keys = { "arrow", "ibeam", "wait", "crosshair", "uparrow",
                                      "sizenwse", "sizenesw", "sizewe", "sizens", "sizeall",
                                      "no", "hand", "appstarting", "help", "nwpen" };

    static IntPtr[] handles;
    public static bool Dirty = true;

    static void Load()
    {
        handles = new IntPtr[Ids.Length];
        for (int i = 0; i < Ids.Length; i++)
            handles[i] = Nat.LoadCursor(IntPtr.Zero, (IntPtr)Ids[i]);
        Dirty = false;
    }

    public static string Detect()
    {
        if (Dirty || handles == null) Load();

        Nat.CURSORINFO ci = new Nat.CURSORINFO();
        ci.cbSize = System.Runtime.InteropServices.Marshal.SizeOf(typeof(Nat.CURSORINFO));
        if (!Nat.GetCursorInfo(ref ci) || ci.hCursor == IntPtr.Zero) return "arrow";

        for (int i = 0; i < handles.Length; i++)
            if (handles[i] != IntPtr.Zero && handles[i] == ci.hCursor) return Keys[i];
        return "arrow";      // 应用自己加载的 .cur（如 Photoshop 画布）一律当箭头
    }
}

class Overlay : Form
{
    const int WS_EX_LAYERED = 0x80000;
    const int WS_EX_TRANSPARENT = 0x20;
    const int WS_EX_TOOLWINDOW = 0x80;
    const int WS_EX_NOACTIVATE = 0x08000000;
    const int CANVAS = 128;          // 内嵌帧的画布尺寸

    readonly Dictionary<string, Frame> frames = new Dictionary<string, Frame>();
    readonly Timer timer = new Timer();

    public bool FollowMode;

    IntPtr dib, oldObj, memDc, bits;
    int w, h;
    string shownKey;
    double animClock, lastMs, stateClock;
    int lastX, lastY;
    bool posed;

    public Overlay(bool follow)
    {
        FollowMode = follow;

        FormBorderStyle = FormBorderStyle.None;
        StartPosition = FormStartPosition.Manual;
        ShowInTaskbar = false;
        TopMost = true;
        Bounds = new Rectangle(0, 0, 1, 1);

        int cursorSize = Nat.GetSystemMetrics(Nat.SM_CXCURSOR);
        if (cursorSize <= 0) cursorSize = 32;

        // 角色约占画布的 76.5%，让它略大于系统光标
        int framePx = (int)Math.Round(cursorSize * 1.35 / 0.765);
        framePx = Math.Max(48, Math.Min(180, framePx));
        w = h = framePx;

        LoadPack();
        CreateSurface();

        Frame f0 = frames["arrow"];
        Draw(f0.Data, 0, 0);

        timer.Interval = 15;
        timer.Tick += Tick;
        timer.Start();
        lastMs = Now();
    }

    static double Now() { return DateTime.Now.Ticks / 10000.0; }

    protected override CreateParams CreateParams
    {
        get
        {
            CreateParams cp = base.CreateParams;
            cp.ExStyle |= WS_EX_LAYERED | WS_EX_TRANSPARENT | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE;
            return cp;
        }
    }

    protected override bool ShowWithoutActivation { get { return true; } }

    void LoadPack()
    {
        using (Stream s = Assembly.GetExecutingAssembly().GetManifestResourceStream("frames.bin"))
        using (BinaryReader r = new BinaryReader(s))
        {
            int n = r.ReadInt32();
            for (int i = 0; i < n; i++)
            {
                int len = r.ReadInt32();
                string name = Encoding.ASCII.GetString(r.ReadBytes(len));
                int hx = r.ReadInt32();
                int hy = r.ReadInt32();
                int dl = r.ReadInt32();
                byte[] png = r.ReadBytes(dl);
                frames[name] = Build(png, hx, hy);
            }
        }
    }

    Frame Build(byte[] png, int hx, int hy)
    {
        Frame f = new Frame();
        using (MemoryStream ms = new MemoryStream(png))
        using (Bitmap src = new Bitmap(ms))
        using (Bitmap scaled = new Bitmap(w, h, PixelFormat.Format32bppArgb))
        {
            using (Graphics g = Graphics.FromImage(scaled))
            {
                g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                g.PixelOffsetMode = PixelOffsetMode.HighQuality;
                g.Clear(Color.Transparent);
                g.DrawImage(src, new Rectangle(0, 0, w, h));
            }
            f.Data = Premultiplied(scaled);
        }
        double k = (double)w / CANVAS;
        f.HotX = (int)Math.Round(hx * k);
        f.HotY = (int)Math.Round(hy * k);
        return f;
    }

    static byte[] Premultiplied(Bitmap bmp)
    {
        BitmapData d = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height),
            ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
        int n = Math.Abs(d.Stride) * bmp.Height;
        byte[] buf = new byte[n];
        Marshal.Copy(d.Scan0, buf, 0, n);
        bmp.UnlockBits(d);
        for (int i = 0; i < n; i += 4)
        {
            int a = buf[i + 3];
            if (a == 255) continue;
            buf[i] = (byte)(buf[i] * a / 255);
            buf[i + 1] = (byte)(buf[i + 1] * a / 255);
            buf[i + 2] = (byte)(buf[i + 2] * a / 255);
        }
        return buf;
    }

    void CreateSurface()
    {
        Nat.BITMAPINFOHEADER bi = new Nat.BITMAPINFOHEADER();
        bi.biSize = 40; bi.biWidth = w; bi.biHeight = -h;
        bi.biPlanes = 1; bi.biBitCount = 32; bi.biCompression = 0;
        IntPtr screen = Nat.GetDC(IntPtr.Zero);
        dib = Nat.CreateDIBSection(screen, ref bi, 0, out bits, IntPtr.Zero, 0);
        memDc = Nat.CreateCompatibleDC(screen);
        oldObj = Nat.SelectObject(memDc, dib);
        Nat.ReleaseDC(IntPtr.Zero, screen);
    }

    void Draw(byte[] data, int x, int y)
    {
        Nat.POINT dst = new Nat.POINT();
        dst.X = x; dst.Y = y;
        Nat.POINT src = new Nat.POINT();
        Nat.SIZE sz = new Nat.SIZE(); sz.cx = w; sz.cy = h;
        Nat.BLENDFUNCTION blend = new Nat.BLENDFUNCTION();
        blend.BlendOp = 0; blend.BlendFlags = 0; blend.SourceConstantAlpha = 255;
        blend.AlphaFormat = Nat.AC_SRC_ALPHA;

        Marshal.Copy(data, 0, bits, data.Length);
        IntPtr screen = Nat.GetDC(IntPtr.Zero);
        Nat.UpdateLayeredWindow(Handle, screen, ref dst, ref sz, memDc, ref src, 0, ref blend, Nat.ULW_ALPHA);
        Nat.ReleaseDC(IntPtr.Zero, screen);
    }

    void Tick(object sender, EventArgs e)
    {
        double now = Now();
        double dt = Math.Max(1.0, now - lastMs);
        lastMs = now;
        stateClock += dt;

        Nat.POINT p;
        if (!Nat.GetCursorPos(out p)) return;
        if (!posed) { lastX = p.X; lastY = p.Y; posed = true; }

        double dx = p.X - lastX, dy = p.Y - lastY;
        double speed = Math.Sqrt(dx * dx + dy * dy) / dt;   // 像素/毫秒
        lastX = p.X; lastY = p.Y;

        string kind = CursorKind.Detect();
        string key;

        if (kind == "wait")
        {
            key = "wait" + ((int)(stateClock / 90) % 6);
        }
        else if (kind == "appstarting")
        {
            key = "app" + ((int)(stateClock / 80) % 12);
        }
        else if (kind == "arrow")
        {
            if (speed > 0.08)
            {
                animClock += dt * (0.6 + Math.Min(speed, 3.0) * 0.7);
                key = "run" + ((int)(animClock / 60.0) % 4);
            }
            else
            {
                key = "arrow";
            }
        }
        else
        {
            key = kind;
        }

        Frame f;
        if (!frames.TryGetValue(key, out f)) f = frames["arrow"];
        shownKey = key;

        int ox = FollowMode ? 26 : 0;
        int oy = FollowMode ? 30 : 0;
        Draw(f.Data, p.X - f.HotX + ox, p.Y - f.HotY + oy);
    }

    public void SetFollow(bool follow)
    {
        FollowMode = follow;
        posed = false;
        CursorKind.Dirty = true;
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            timer.Stop();
            if (memDc != IntPtr.Zero)
            {
                Nat.SelectObject(memDc, oldObj);
                Nat.DeleteDC(memDc);
                Nat.DeleteObject(dib);
                memDc = IntPtr.Zero;
            }
        }
        base.Dispose(disposing);
    }
}

static class Program
{
    [STAThread]
    static void Main(string[] args)
    {
        try { MainCore(args); }
        catch (Exception ex) { Log(ex); }
    }

    static void Log(Exception ex)
    {
        try
        {
            string msg;
            try { msg = ex.GetType().FullName + " :: " + ex.Message; }
            catch { msg = "unknown exception"; }
            string st = "";
            try { st = ex.StackTrace; } catch { }
            File.AppendAllText(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "err.log"),
                DateTime.Now.ToString("HH:mm:ss") + "  " + msg + Environment.NewLine + st + Environment.NewLine);
        }
        catch { }
    }

    static void MainCore(string[] args)
    {
        Nat.SetProcessDPIAware();

        if (Has(args, "--restore")) { RestoreCursor(); return; }

        bool created;
        using (Mutex only = new Mutex(true, "Local\\XiaoHuangPet", out created))
        {
            if (!created) return;                 // 已经在跑
            Run(args);
        }
    }

    static bool Has(string[] args, string flag) { return Array.IndexOf(args, flag) >= 0; }

    static string Arg(string[] args, string flag)
    {
        int i = Array.IndexOf(args, flag);
        if (i >= 0 && i + 1 < args.Length) return args[i + 1];
        return null;
    }

    static void Run(string[] args)
    {
        string modeArg = Arg(args, "--mode");
        if (modeArg == "follow" || modeArg == "replace") Settings.Mode = modeArg;
        bool follow = Settings.Mode == "follow";

        int seconds = 0;
        string sArg = Arg(args, "--seconds");
        if (sArg != null) int.TryParse(sArg, out seconds);

        Normalize();
        if (!follow) HideCursor();

        Application.ThreadException += delegate { RestoreCursor(); };
        AppDomain.CurrentDomain.UnhandledException += delegate { RestoreCursor(); };

        Overlay form = null;
        Tray tray = null;
        Timer quit = new Timer();
        try
        {
            form = new Overlay(follow);
            tray = new Tray(form);
            form.Show();
            if (seconds > 0)
            {
                quit.Interval = seconds * 1000;
                quit.Tick += delegate { Application.Exit(); };
                quit.Start();
            }
            Application.Run(form);
        }
        finally
        {
            quit.Stop();
            if (tray != null) tray.Dispose();
            if (form != null) form.Dispose();
            RestoreCursor();
        }
    }

    public static void Normalize()
    {
        for (int i = 0; i < 64 && Nat.ShowCursor(true) < 0; i++) { }
        for (int i = 0; i < 64 && Nat.ShowCursor(false) > 0; i++) { }
    }

    public static void HideCursor() { CursorHider.Hide(); CursorKind.Dirty = true; }

    public static void RestoreCursor() { CursorHider.Restore(); CursorKind.Dirty = true; }
}

static class CursorHider
{
    static bool blanked;

    static readonly uint[] Ids = { 32512, 32513, 32514, 32515, 32516,
                                   32642, 32643, 32644, 32645, 32646, 32648, 32649, 32650, 32651 };

    static readonly string[] Defaults = {
        "32512|aero_arrow.cur", "32513|beam_i.cur", "32514|aero_busy.ani", "32515|cross_i.cur",
        "32516|aero_up.cur", "32642|aero_nwse.cur", "32643|aero_nesw.cur", "32644|aero_ew.cur",
        "32645|aero_ns.cur", "32646|aero_move.cur", "32648|aero_unavail.cur", "32649|aero_link.cur",
        "32650|aero_working.ani", "32651|aero_helpsel.cur"
    };

    static readonly string[] RegNames = {
        "Arrow", "IBeam", "Wait", "Crosshair", "UpArrow",
        "SizeNWSE", "SizeNESW", "SizeWE", "SizeNS", "SizeAll", "No", "Hand", "AppStarting", "Help"
    };

    static bool Visible()
    {
        Nat.CURSORINFO ci = new Nat.CURSORINFO();
        ci.cbSize = System.Runtime.InteropServices.Marshal.SizeOf(typeof(Nat.CURSORINFO));
        if (!Nat.GetCursorInfo(ref ci)) return true;
        return (ci.flags & 1) != 0;
    }

    public static void Hide()
    {
        for (int i = 0; i < 64 && Nat.ShowCursor(false) >= 0; i++) { }
        if (!Visible()) return;                       // 计数器生效了，不用动系统光标

        byte[] andPlane = new byte[32 * 32 / 8];
        for (int i = 0; i < andPlane.Length; i++) andPlane[i] = 0xFF;
        byte[] xorPlane = new byte[32 * 32 * 4];
        IntPtr blank = Nat.CreateCursor(IntPtr.Zero, 0, 0, 32, 32, andPlane, xorPlane);
        if (blank == IntPtr.Zero) return;
        foreach (uint id in Ids) Nat.SetSystemCursor(Nat.CopyIcon(blank), id);
        Nat.DestroyCursor(blank);
        blanked = true;
    }

    public static void Restore()
    {
        for (int i = 0; i < 64 && Nat.ShowCursor(true) < 0; i++) { }
        if (!blanked) return;
        blanked = false;

        if (Nat.SystemParametersInfo(0x0057, 0, IntPtr.Zero, 0)) return;   // SPI_SETCURSORS
        RestoreFromFiles();
    }

    static void RestoreFromFiles()
    {
        string root = @"C:\Windows\Cursors\";
        for (int i = 0; i < Ids.Length; i++)
        {
            string path = null;
            try
            {
                using (RegistryKey k = Registry.CurrentUser.OpenSubKey(@"Control Panel\Cursors"))
                    if (k != null) path = k.GetValue(RegNames[i]) as string;
            }
            catch { }
            if (string.IsNullOrEmpty(path) || !File.Exists(path))
                path = root + Defaults[i].Substring(Defaults[i].IndexOf('|') + 1);
            if (!File.Exists(path)) continue;
            IntPtr h = Nat.LoadImage(IntPtr.Zero, path, 2, 0, 0, 0x10);
            if (h != IntPtr.Zero) Nat.SetSystemCursor(h, Ids[i]);
        }
    }
}

class Tray : IDisposable
{
    readonly NotifyIcon icon = new NotifyIcon();
    readonly Overlay form;
    readonly MenuItem miReplace, miFollow, miAuto;

    public Tray(Overlay form)
    {
        this.form = form;

        miReplace = new MenuItem("替换模式（团子就是光标）", new EventHandler(OnReplace));
        miFollow = new MenuItem("跟随模式（保留系统箭头）", new EventHandler(OnFollow));
        miAuto = new MenuItem("开机自动启动", new EventHandler(OnAuto));

        icon.Icon = AppIcon();
        icon.Text = "小黄团子光标";
        icon.ContextMenu = new ContextMenu(new MenuItem[] {
            miReplace, miFollow,
            new MenuItem("-"),
            miAuto,
            new MenuItem("-"),
            new MenuItem("退出", new EventHandler(OnQuit))
        });
        icon.Visible = true;
        Refresh();
    }

    static Icon AppIcon()
    {
        try
        {
            using (Stream s = Assembly.GetExecutingAssembly().GetManifestResourceStream("app.ico"))
                if (s != null) return new Icon(s, new Size(16, 16));
        }
        catch { }
        return SystemIcons.Application;
    }

    void Refresh()
    {
        miReplace.Checked = !form.FollowMode;
        miFollow.Checked = form.FollowMode;
        miAuto.Checked = Settings.AutoStart;
    }

    void OnReplace(object s, EventArgs e)
    {
        form.SetFollow(false);
        Settings.Mode = "replace";
        Program.HideCursor();
        Refresh();
    }

    void OnFollow(object s, EventArgs e)
    {
        form.SetFollow(true);
        Settings.Mode = "follow";
        Program.RestoreCursor();
        Refresh();
    }

    void OnAuto(object s, EventArgs e)
    {
        bool ok = Settings.SetAutoStart(!Settings.AutoStart, Application.ExecutablePath);
        if (!ok) MessageBox.Show("写注册表被拦截了，可能被安全软件挡住。", "开不了自启");
        Refresh();
    }

    void OnQuit(object s, EventArgs e) { Application.Exit(); }

    public void Dispose()
    {
        icon.Visible = false;
        icon.Dispose();
    }
}
