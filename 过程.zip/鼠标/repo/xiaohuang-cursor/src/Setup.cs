using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Microsoft.Win32;

// 小黄团子光标 —— 安装 / 卸载程序（免管理员，装到当前用户）
// 双击运行；也可命令行：/install /quiet  、 /uninstall /quiet

static class Inst
{
    public const string AppName = "小黄团子光标";

    public static string DirOverride = null;   // 调试用：/dir:<路径>
    public static string Chosen = null;        // 实际选定的安装目录

    public static string DefaultDir
    {
        get
        {
            return Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "XiaoHuangPet");
        }
    }

    public static string Dir
    {
        get
        {
            if (!string.IsNullOrEmpty(Chosen)) return Chosen;
            if (!string.IsNullOrEmpty(DirOverride)) return DirOverride;
            return DefaultDir;
        }
    }

    // 候选安装位置：用户目录 → 漫游目录 → 安装包所在目录（受限环境下的兜底）
    static string[] Candidates()
    {
        return new string[] {
            DefaultDir,
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "XiaoHuangPet"),
            Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), "XiaoHuangPet")
        };
    }

    public static string ExePath { get { return Path.Combine(Dir, "MousePet.exe"); } }

    public static bool Installed
    {
        get
        {
            foreach (string cand in Candidates())
            {
                if (File.Exists(Path.Combine(cand, "MousePet.exe")))
                {
                    Chosen = cand;
                    return true;
                }
            }
            return false;
        }
    }

    [DllImport("user32.dll")] static extern int ShowCursor(bool bShow);
    [DllImport("user32.dll")] static extern bool SystemParametersInfo(uint a, uint p, IntPtr v, uint f);

    public static void RestoreCursor()
    {
        for (int i = 0; i < 64 && ShowCursor(true) < 0; i++) { }
    }

    public static void KillApp()
    {
        if (File.Exists(ExePath))          // 先让主程序自己把光标还原
        {
            try
            {
                ProcessStartInfo psi = new ProcessStartInfo(ExePath, "--restore");
                psi.UseShellExecute = false;
                psi.CreateNoWindow = true;
                Process r = Process.Start(psi);
                r.WaitForExit(2000);
            }
            catch { }
        }
        foreach (Process p in Process.GetProcessesByName("MousePet"))
        {
            try { p.Kill(); p.WaitForExit(2000); }
            catch { }
        }
        try { SystemParametersInfo(0x0057, 0, IntPtr.Zero, 0); } catch { }
        RestoreCursor();
    }

    static void SetRun(bool on)
    {
        using (RegistryKey k = Registry.CurrentUser.OpenSubKey(
            @"Software\Microsoft\Windows\CurrentVersion\Run", true))
        {
            if (k == null) return;
            if (on) k.SetValue("XiaoHuangPet", "\"" + ExePath + "\" --auto");
            else if (k.GetValue("XiaoHuangPet") != null) k.DeleteValue("XiaoHuangPet", false);
        }
    }

    public static bool RunEnabled
    {
        get
        {
            using (RegistryKey k = Registry.CurrentUser.OpenSubKey(
                @"Software\Microsoft\Windows\CurrentVersion\Run"))
                return k != null && k.GetValue("XiaoHuangPet") != null;
        }
    }

    public static bool Install(bool autostart, bool launch)
    {
        KillApp();

        // 依次试候选目录，挑第一个真正可写的
        string target = null;
        string lastError = null;
        foreach (string cand in Candidates())
        {
            try
            {
                Directory.CreateDirectory(cand);
                string probe = Path.Combine(cand, ".write_test");
                File.WriteAllText(probe, "ok");
                File.Delete(probe);
                target = cand;
                break;
            }
            catch (Exception ex) { lastError = ex.Message; }
        }
        if (target == null)
            throw new InvalidOperationException(
                "没有可写的安装位置。请把安装包拖到桌面后双击运行（不要从聊天窗口里打开）。详情：" + lastError);

        Chosen = target;
        using (Stream s = Assembly.GetExecutingAssembly().GetManifestResourceStream("MousePet.exe"))
        {
            if (s == null) throw new InvalidOperationException("安装包损坏：找不到主程序");
            using (FileStream f = File.Create(ExePath)) s.CopyTo(f);
        }
        bool runOk = true;
        try { SetRun(autostart); }
        catch { runOk = false; }
        if (launch)
        {
            try { Process.Start(ExePath, "--auto"); }
            catch (Exception ex) { throw new InvalidOperationException("启动失败：" + ex.Message, ex); }
        }
        return runOk;
    }

    public static void Uninstall()
    {
        bool wasInstalled = Installed;   // 定位实际安装目录（可能是备用位置）
        if (!wasInstalled) { /* 没装过也照常清理残留 */ }
        KillApp();
        try { SetRun(false); } catch { }
        try { Registry.CurrentUser.DeleteSubKeyTree(@"Software\XiaoHuangPet", false); }
        catch { }
        // 三个候选位置都清一遍，顺手清掉以前残留的
        foreach (string cand in Candidates())
        {
            for (int i = 0; i < 6 && Directory.Exists(cand); i++)
            {
                try { Directory.Delete(cand, true); }
                catch { System.Threading.Thread.Sleep(200); }
            }
        }
        RestoreCursor();
    }
}

class Setup : Form
{
    readonly Label status = new Label();
    readonly CheckBox chkAuto = new CheckBox();
    readonly CheckBox chkRun = new CheckBox();
    readonly Button btnInstall = new Button();
    readonly Button btnRemove = new Button();

    static readonly Color Ink = Color.FromArgb(42, 36, 28);
    static readonly Color Sub = Color.FromArgb(140, 132, 120);
    static readonly Color Accent = Color.FromArgb(255, 196, 46);

    public Setup()
    {
        Text = "小黄团子光标 · 安装程序";
        ClientSize = new Size(492, 344);
        FormBorderStyle = FormBorderStyle.FixedSingle;
        MaximizeBox = false;
        StartPosition = FormStartPosition.CenterScreen;
        BackColor = Color.FromArgb(253, 251, 246);
        Font = new Font("Microsoft YaHei UI", 9f);
        try { Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath); }
        catch { }

        PictureBox pic = new PictureBox();
        pic.Bounds = new Rectangle(26, 24, 64, 64);
        pic.SizeMode = PictureBoxSizeMode.Zoom;
        try { pic.Image = Icon.ToBitmap(); }
        catch { }
        Controls.Add(pic);

        Label title = new Label();
        title.Text = "小黄团子光标";
        title.Font = new Font("Microsoft YaHei UI", 16f, FontStyle.Bold);
        title.ForeColor = Ink;
        title.Bounds = new Rectangle(104, 24, 360, 32);
        Controls.Add(title);

        Label sub = new Label();
        sub.Text = "鼠标一动就小跑，停下站好。装完常驻托盘，可开机自启。";
        sub.ForeColor = Sub;
        sub.Bounds = new Rectangle(106, 60, 370, 24);
        Controls.Add(sub);

        Panel line = new Panel();
        line.BackColor = Color.FromArgb(232, 228, 219);
        line.Bounds = new Rectangle(26, 100, 440, 1);
        Controls.Add(line);

        status.Bounds = new Rectangle(26, 110, 440, 56);
        status.ForeColor = Ink;
        status.Font = new Font("Microsoft YaHei UI", 9.5f);
        Controls.Add(status);

        chkAuto.Text = "开机自动启动（装进后台，下次开机自己回来）";
        chkAuto.Checked = true;
        chkAuto.Bounds = new Rectangle(26, 158, 420, 24);
        chkAuto.ForeColor = Ink;
        Controls.Add(chkAuto);

        chkRun.Text = "安装完成后立即运行";
        chkRun.Checked = true;
        chkRun.Bounds = new Rectangle(26, 186, 420, 24);
        chkRun.ForeColor = Ink;
        Controls.Add(chkRun);

        Label where = new Label();
        where.Text = "安装位置：%LOCALAPPDATA%\\XiaoHuangPet（无需管理员权限）";
        where.ForeColor = Sub;
        where.Bounds = new Rectangle(26, 218, 440, 34);
        Controls.Add(where);

        btnInstall.Text = "安 装";
        btnInstall.Bounds = new Rectangle(268, 278, 96, 38);
        Style(btnInstall, true);
        btnInstall.Click += OnInstall;
        Controls.Add(btnInstall);

        btnRemove.Text = "卸 载";
        btnRemove.Bounds = new Rectangle(372, 278, 94, 38);
        Style(btnRemove, false);
        btnRemove.Click += OnRemove;
        Controls.Add(btnRemove);

        Button btnClose = new Button();
        btnClose.Text = "关闭";
        btnClose.Bounds = new Rectangle(174, 278, 86, 38);
        Style(btnClose, false);
        btnClose.Click += delegate { Close(); };
        Controls.Add(btnClose);

        RefreshState();
    }

    static void Style(Button b, bool accent)
    {
        b.FlatStyle = FlatStyle.Flat;
        b.FlatAppearance.BorderSize = 0;
        b.BackColor = accent ? Accent : Color.FromArgb(238, 234, 226);
        b.ForeColor = accent ? Color.FromArgb(60, 44, 10) : Color.FromArgb(70, 64, 56);
        b.Font = new Font("Microsoft YaHei UI", 10f, FontStyle.Bold);
        b.Cursor = Cursors.Hand;
    }

    void RefreshState()
    {
        bool on = Inst.Installed;
        btnInstall.Enabled = !on;
        btnRemove.Enabled = on;
        chkAuto.Enabled = !on;
        chkRun.Enabled = !on;

        if (on)
        {
            status.Text = "已经装好了。托盘里能看到团子图标；右键可以切模式、开关自启。" +
                (Inst.RunEnabled ? "" : "\n提示：当前没有勾选开机自启。");
            chkAuto.Checked = Inst.RunEnabled;
        }
        else
        {
            status.Text = "点「安装」即可。全程 2 秒，不需要管理员权限，随时可以在这里卸载。";
        }
    }

    void OnInstall(object s, EventArgs e)
    {
        btnInstall.Enabled = false;
        Application.DoEvents();
        try
        {
            bool runOk = Inst.Install(chkAuto.Checked, chkRun.Checked);
            string where = Inst.Dir;
            bool std = string.Equals(where, Inst.DefaultDir, StringComparison.OrdinalIgnoreCase);
            status.Text = "安装完成 ✓  位置：" + where + Environment.NewLine +
                (runOk ? "托盘里能看到团子图标（右键可切模式）。"
                       : "自启项没写进去（被拦截了），可在托盘里再点一次「开机自动启动」。") +
                (std ? "" : Environment.NewLine + "提示：装到了备用目录，建议把安装包拖到桌面双击运行。");
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "安装失败：" + ex.Message, "出错了", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        RefreshState();
        if (Inst.Installed) status.Text = "安装完成 ✓  团子已经上岗了。托盘图标右键可退出。";
    }

    void OnRemove(object s, EventArgs e)
    {
        if (MessageBox.Show(this, "卸载后会删除程序并取消开机自启，鼠标指针恢复成 Windows 默认。继续？",
                "确认卸载", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
        try
        {
            Inst.Uninstall();
            status.Text = "已卸载，光标已恢复。";
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "卸载失败：" + ex.Message, "出错了", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        RefreshState();
        if (!Inst.Installed) status.Text = "已卸载，光标已恢复。";
    }
}

static class Program
{
    [STAThread]
    static void Main(string[] args)
    {
        try { MainCore(args); }
        catch (Exception ex)
        {
            try
            {
                string msg;
                try { msg = ex.GetType().FullName + " :: " + ex.Message; } catch { msg = "unknown"; }
                File.AppendAllText(Path.Combine(Path.GetDirectoryName(
                    System.Reflection.Assembly.GetExecutingAssembly().Location), "setup_err.log"),
                    DateTime.Now.ToString("HH:mm:ss") + " " + msg + Environment.NewLine);
            }
            catch { }
        }
    }

    static void MainCore(string[] args)
    {
        bool quiet = Array.IndexOf(args, "/quiet") >= 0 || Array.IndexOf(args, "-quiet") >= 0;
        for (int i = 0; i < args.Length; i++)
            if (args[i].StartsWith("/dir:")) Inst.DirOverride = args[i].Substring(5);

        if (Array.IndexOf(args, "/install") >= 0)
        {
            bool auto = Array.IndexOf(args, "/noautostart") < 0;
            bool launch = Array.IndexOf(args, "/nolaunch") < 0;
            Inst.Install(auto, launch);
            if (!quiet) MessageBox.Show("安装完成");
            return;
        }
        if (Array.IndexOf(args, "/uninstall") >= 0)
        {
            Inst.Uninstall();
            if (!quiet) MessageBox.Show("已卸载");
            return;
        }

        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        Application.Run(new Setup());
    }
}
