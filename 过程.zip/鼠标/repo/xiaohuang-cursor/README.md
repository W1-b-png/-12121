# xiaohuang-cursor · 小黄团子光标

一个 **会跟着鼠标跑** 的 Windows 光标程序。鼠标一动，角色就小跑；停下就站好；
悬停在文本框、链接上，或者程序忙的时候，还会切换成对应的表情和动作。

A mouse cursor overlay for Windows: the character runs while your cursor moves,
stands still when you stop, and changes pose with the system cursor type.

![跟随效果](assets/screenshot.png)

## 特性

- **逐像素透明覆盖层**：`WS_EX_LAYERED | TRANSPARENT | TOPMOST | NOACTIVATE`，
  点击穿透、不抢焦点、不挡操作
- **状态跟随**：每 16 ms 读一次系统当前光标类型（`GetCursorInfo` + `LoadCursor` 句柄比对），
  自动切换 17 种画面
- **速度驱动**：位移 / 时间决定帧推进速度，动得越快跑得越急，停下立刻站立
- **两种模式**：替换模式（隐藏系统箭头，团子就是指针）/ 跟随模式（保留箭头）
- **安装包**：免管理员、装到当前用户、开机自启、托盘菜单、一键卸载
- **另附指针包**：17 个状态的 `.cur` / `.ani`，不装程序也能直接在「鼠标属性」里用

## 状态对照

| 系统光标 | 团子表现 |
|---|---|
| 箭头 | 站着 / 移动时小跑 |
| 文本 I 形 | 举着 I 形光标 |
| 链接手形 | 举起小手 |
| 忙 | 思考气泡，点逐个冒出（6 帧） |
| 后台运行 | 左下角转圈（12 帧） |
| 精确选择 | 十字准星 |
| 调整大小 / 移动 | 身体压扁成对应箭头 |
| 禁止 | 眼睛变成 ×× |
| 候选 / 手写 / 帮助 / 定位 / 人像 | 对应画面 |

## 快速开始

**方式一：装程序**（推荐，能跑动、能换状态）

1. 到 [Releases](../../releases) 下载 `Setup.exe`
2. 双击 → 点「安装」→ 完成（2 秒，不弹 UAC）
3. 托盘图标右键可以切模式、开关开机自启、退出
4. 卸载：再双击一次安装包 → 点「卸载」

**方式二：只换指针**（静态，不装程序）

`cursors/` 里的文件直接在「`Win+R` → `control mouse` → 指针」里逐项「浏览」指定即可。

## 自己构建

只需要 Windows 自带的 .NET Framework 4.x 编译器，**不用装 SDK**：

```powershell
.\build.ps1
```

产物：`build\MousePet.exe`（光标程序）、`build\Setup.exe`（安装包）。

修改角色素材才需要 Python 3 + Pillow：

```bash
python tools/extract_sprite.py 素材.png   # 抠图，输出 assets/sprite.png
python tools/gen.py                       # 生成 17 张状态图到 png/
python tools/frames.py                    # 生成两个动画的帧
python tools/pack_frames.py               # 打包成 assets/frames.bin
python tools/build.py                     # 打包 .cur / .ani 到 cursors/
```

## 工作原理

1. **定位**：15 ms 定时器轮询 `GetCursorPos`，用位移 ÷ 时间算出速度
2. **选帧**：速度超阈值 → 小跑帧（速度越快推进越快）；否则站立帧
3. **识别状态**：`GetCursorInfo` 拿到当前光标句柄，和预载的 15 种标准光标句柄比对，
   映射成文本 / 链接 / 忙 / 十字 / 调整大小…
4. **绘制**：一个分层窗口 + `UpdateLayeredWindow` 逐像素合成（预乘 alpha），
   窗口左上角 = 光标坐标 − 热点，所以点击落点始终准确
5. **隐藏箭头**（替换模式）：先试 `ShowCursor`，检测到没生效再用 `SetSystemCursor`
   把 14 个标准光标换成全透明；退出、异常、卸载、`--restore` 都会还原

## 目录

```
src/            MousePet.cs（光标程序）、Setup.cs（安装/卸载程序）
tools/          Python 素材流水线 + png2cur.py
assets/         预览图、截图、角色精灵、内嵌帧包 frames.bin、图标
png/            17 张 256px 状态图 + 三个动画的逐帧图
cursors/        18 个成品光标（15 个 .cur + 3 个 .ani）
docs/           制作流程、指针包说明
build.ps1       一键构建
```

## 已知边界

- 全屏独占游戏、带反作弊的程序、远程桌面里覆盖层可能不显示
- 应用自己加载的 `.cur`（Photoshop 画布、部分游戏）识别不到，会退回箭头状态
- 多显示器且 DPI 不同时，位置可能差几像素
- 安装包未签名，首次运行 Windows 可能提示「已保护你的电脑」→ 更多信息 → 仍要运行

## 素材说明

角色形象来自使用者提供的渲染图，仅用于演示这个项目。
如果涉及版权问题，请联系删除，代码部分（MIT）不受影响。

## License

[MIT](LICENSE)
