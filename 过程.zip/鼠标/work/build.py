# -*- coding: utf-8 -*-
"""把 png/ 里的状态图打包成 Windows 光标：.cur（多尺寸） + .ani（动画帧）"""
import os
import struct
import sys

sys.path.insert(0, r"C:\Users\LENOVO\Desktop\鼠标")
from png2cur import png_to_cur          # noqa: E402

BASE = r"C:\Users\LENOVO\Desktop\鼠标"
PNG = BASE + r"\png"
OUT = BASE + r"\cursors"
SIZES = (32, 48, 64, 96, 128)

# 状态 -> (文件名, 256 坐标系下的热点)
SPEC = {
    "arrow": ("arrow.cur", (124, 56)),
    "help": ("help.cur", (120, 56)),
    "crosshair": ("crosshair.cur", (86, 96)),
    "ibeam": ("ibeam.cur", (76, 96)),
    "nwpen": ("nwpen.cur", (40, 40)),
    "no": ("no.cur", (128, 112)),
    "sizens": ("sizens.cur", (128, 128)),
    "sizewe": ("sizewe.cur", (128, 128)),
    "sizenwse": ("sizenwse.cur", (128, 128)),
    "sizenesw": ("sizenesw.cur", (128, 128)),
    "sizeall": ("sizeall.cur", (128, 128)),
    "uparrow": ("uparrow.cur", (66, 26)),
    "hand": ("hand.cur", (59, 46)),
    "pin": ("pin.cur", (62, 152)),
    "person": ("person.cur", (62, 64)),
}


def cur_chunk(png_path, size, hot):
    """生成单尺寸的 .cur 字节（用作 .ani 的一帧）"""
    tmp = PNG + r"\_tmp.cur"
    png_to_cur(png_path, tmp, hotspot=hot, sizes=[size])
    data = open(tmp, "rb").read()
    os.remove(tmp)
    return data


def riff_chunk(tag: bytes, data: bytes) -> bytes:
    pad = b"\0" if len(data) % 2 else b""
    return tag + struct.pack("<I", len(data)) + data + pad


def build_ani(frames, hot, size=96, jiffies=4):
    """frames: 图片路径列表；jiffies = 1/60 秒"""
    icons = [riff_chunk(b"icon", cur_chunk(f, size, hot)) for f in frames]
    n = len(icons)
    anih = struct.pack("<9I", 36, n, n, size, size, 32, 1, jiffies, 1)   # 1 = AF_ICON
    rate = struct.pack(f"<{n}I", *([jiffies] * n))
    seq = struct.pack(f"<{n}I", *range(n))
    fram = riff_chunk(b"LIST", b"fram" + b"".join(icons))
    body = b"ACON" + riff_chunk(b"anih", anih) + riff_chunk(b"rate", rate) \
        + riff_chunk(b"seq ", seq) + fram
    return b"RIFF" + struct.pack("<I", len(body)) + body


def main():
    os.makedirs(OUT, exist_ok=True)
    for name, (fname, hot) in SPEC.items():
        png_to_cur(f"{PNG}\\{name}.png", f"{OUT}\\{fname}", hotspot=hot, sizes=SIZES)
        print(f"{fname:14s} hotspot={hot}  {os.path.getsize(f'{OUT}\\{fname}') // 1024} KB")

    for name, fname, n, jif in [("wait", "wait.ani", None, 4), ("appstarting", "appstarting.ani", 12, 4)]:
        frames = sorted(
            f for f in os.listdir(PNG + r"\动画帧")
            if f.startswith(name + "_f") and f.endswith(".png")
        )
        if not frames:
            print(f"[跳过] {name}: 没有动画帧")
            continue
        data = build_ani([f"{PNG}\\动画帧\\{f}" for f in frames], SPEC_HOT[name], jiffies=jif)
        open(f"{OUT}\\{fname}", "wb").write(data)
        print(f"{fname:14s} {len(frames)} 帧  {len(data) // 1024} KB")


SPEC_HOT = {"wait": (120, 56), "appstarting": (120, 56)}

if __name__ == "__main__":
    main()
