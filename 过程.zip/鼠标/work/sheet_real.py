# -*- coding: utf-8 -*-
"""按真实光标尺寸（32/48/96）检查可读性"""
from PIL import Image, ImageDraw, ImageFont

BASE = r"C:\Users\LENOVO\Desktop\鼠标"
NAMES = ["arrow", "wait", "no", "hand", "ibeam", "sizens", "sizewe", "sizeall"]
SIZES = [32, 48, 96]
BG = [(250, 250, 248), (240, 240, 236), (46, 48, 54)]

cell_w = sum(s + 26 for s in SIZES) + 24
row_h = max(SIZES) + 30
sheet = Image.new("RGB", (cell_w * len(NAMES) + 10, row_h * len(BG) + 40), (255, 255, 255))
dr = ImageDraw.Draw(sheet)
font = ImageFont.truetype("C:/Windows/Fonts/msyh.ttc", 13)

for bi, bgc in enumerate(BG):
    y0 = 30 + bi * row_h
    dr.text((6, y0 - 18), f"背景 {['白','浅灰','深色'][bi]}", font=font, fill=(30, 30, 30))
    for ni, name in enumerate(NAMES):
        x0 = 10 + ni * cell_w
        dr.text((x0, 6), name, font=font, fill=(30, 30, 30))
        x = x0
        for s in SIZES:
            im = Image.open(f"{BASE}\\png\\{name}.png").resize((s, s), Image.LANCZOS)
            cell = Image.new("RGB", (s + 8, row_h - 8), bgc)
            cell.paste(im, (4, 4), im)
            sheet.paste(cell, (x, y0))
            x += s + 26
sheet.save(BASE + r"\work\sheet_realsize.png")
print(sheet.size)
