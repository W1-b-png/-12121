# 重新编译 MousePet.exe（改了 MousePet.cs 或换了帧之后跑这个）
$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $PSScriptRoot          # 项目根目录
$dir  = Join-Path $root "鼠标奔跑工具"
$fr   = Join-Path $root "work\runframes"
$csc  = "C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe"

& $csc /nologo /target:winexe /out:"$dir\MousePet.exe" `
    /r:System.dll /r:System.Drawing.dll /r:System.Windows.Forms.dll `
    /resource:"$fr\idle.png",idle.png `
    /resource:"$fr\run0.png",run0.png `
    /resource:"$fr\run1.png",run1.png `
    /resource:"$fr\run2.png",run2.png `
    /resource:"$fr\run3.png",run3.png `
    "$dir\MousePet.cs"

if ($LASTEXITCODE -eq 0) { Write-Host "编译完成 -> $dir\MousePet.exe" } else { Write-Host "编译失败" }
