# -*- coding: utf-8 -*-
"""把所有状态排成预览图，检查视觉一致性"""
import glob
import os

from PIL import Image, ImageDraw, ImageFont

BASE = r"C:\Users\LENOVO\Desktop\鼠标"
PNG = BASE + r"\png"

ORDER = ["arrow", "help", "appstarting", "wait", "crosshair", "ibeam", "nwpen", "no",
         "sizens", "sizewe", "sizenwse", "sizenesw", "sizeall", "uparrow", "hand", "pin",
         "person"]
LABEL = {"arrow": "正常选择", "help": "帮助选择", "appstarting": "后台运行", "wait": "忙",
         "crosshair": "精确选择", "ibeam": "文本选择", "nwpen": "手写", "no": "不可用",
         "sizens": "垂直调整", "sizewe": "水平调整", "sizenwse": "对角1", "sizenesw": "对角2",
         "sizeall": "移动", "uparrow": "候选", "hand": "链接选择", "pin": "位置选择",
         "person": "个人选择"}

CELL = 150
PAD = 10
COLS = 6
ROWS = (len(ORDER) + COLS - 1) // COLS
BG = (238, 238, 236)

W = COLS * (CELL + PAD) + PAD
H = ROWS * (CELL + 34) + PAD
sheet = Image.new("RGB", (W, H), BG)
d = ImageDraw.Draw(sheet)
try:
    font = ImageFont.truetype("C:/Windows/Fonts/msyh.ttc", 15)
except OSError:
    font = ImageFont.load_default()

for i, name in enumerate(ORDER):
    r, c = divmod(i, COLS)
    x = PAD + c * (CELL + PAD)
    y = PAD + r * (CELL + 34)
    cell = Image.new("RGB", (CELL, CELL), (250, 250, 248))
    cd = ImageDraw.Draw(cell)
    # 浅色/深色各半，检查可见性
    cd.rectangle([0, 0, CELL, CELL // 2], fill=(250, 250, 248))
    cd.rectangle([0, CELL // 2, CELL, CELL], fill=(44, 46, 52))
    im = Image.open(f"{PNG}\\{name}.png")
    im = im.resize((CELL - 16, CELL - 16), Image.LANCZOS)
    cell.paste(im, (8, 8), im)
    sheet.paste(cell, (x, y))
    d.rectangle([x, y, x + CELL, y + CELL], outline=(196, 196, 192))
    d.text((x + 4, y + CELL + 6), f"{LABEL[name]} / {name}", font=font, fill=(40, 40, 40))

sheet.save(BASE + r"\work\sheet_states.png")
print("sheet:", sheet.size)

# 小尺寸可读性：32px 一行，放大 4 倍展示
small = Image.new("RGB", (len(ORDER) * 44 + 10, 60), BG)
for i, name in enumerate(ORDER):
    im = Image.open(f"{PNG}\\{name}.png").resize((32, 32), Image.LANCZOS)
    bg = Image.new("RGB", (32, 32), (250, 250, 248))
    bg.paste(im, (0, 0), im)
    small.paste(bg.resize((32, 32)), (10 + i * 44, 14))
small = small.resize((small.width * 3, small.height * 3), Image.NEAREST)
small.save(BASE + r"\work\sheet_small.png")
print("small:", small.size)
