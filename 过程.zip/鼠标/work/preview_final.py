# -*- coding: utf-8 -*-
"""生成最终预览图"""
from PIL import Image, ImageDraw, ImageFont

BASE = r"C:\Users\LENOVO\Desktop\鼠标"
PNG = BASE + r"\png"

ITEMS = [
    ("arrow", "正常选择", "Arrow"),
    ("help", "帮助选择", "Help"),
    ("appstarting", "后台运行", "AppStarting"),
    ("wait", "忙 · 思考中", "Wait"),
    ("crosshair", "精确选择", "Crosshair"),
    ("ibeam", "文本选择", "IBeam"),
    ("nwpen", "手写", "NWPen"),
    ("no", "不可用", "No"),
    ("sizens", "垂直调整", "SizeNS"),
    ("sizewe", "水平调整", "SizeWE"),
    ("sizenwse", "对角调整 1", "SizeNWSE"),
    ("sizenesw", "对角调整 2", "SizeNESW"),
    ("sizeall", "移动", "SizeAll"),
    ("uparrow", "候选", "UpArrow"),
    ("hand", "链接选择", "Hand"),
    ("pin", "位置选择", "Pin"),
    ("person", "个人选择", "Person"),
]

COLS = 6
PAD = 14
ICON = 150
CELL_H = ICON + 52
BG = (247, 246, 243)
CARD = (255, 255, 255)

rows = (len(ITEMS) + COLS - 1) // COLS
W = PAD + COLS * (ICON + PAD)
H = 96 + rows * (CELL_H + PAD)

img = Image.new("RGB", (W, H), BG)
d = ImageDraw.Draw(img)

f_title = ImageFont.truetype("C:/Windows/Fonts/msyhbd.ttc", 30)
f_sub = ImageFont.truetype("C:/Windows/Fonts/msyh.ttc", 15)
f_name = ImageFont.truetype("C:/Windows/Fonts/msyh.ttc", 17)
f_key = ImageFont.truetype("C:/Windows/Fonts/consola.ttf", 13)

d.text((PAD + 6, 26), "小黄团子 · 鼠标指针包", font=f_title, fill=(38, 34, 28))
d.text((PAD + 8, 66), "17 个状态 · 32/48/64/96/128 多尺寸 · 32 位透明 · 深色描边", font=f_sub, fill=(120, 114, 104))

for i, (name, cn, key) in enumerate(ITEMS):
    r, c = divmod(i, COLS)
    x = PAD + c * (ICON + PAD)
    y = 96 + r * (CELL_H + PAD)
    d.rounded_rectangle([x, y, x + ICON, y + CELL_H], radius=14, fill=CARD, outline=(226, 223, 216))
    im = Image.open(f"{PNG}\\{name}.png").resize((ICON - 22, ICON - 22), Image.LANCZOS)
    img.paste(im, (x + 11, y + 11), im)
    d.text((x + 12, y + ICON - 2), cn, font=f_name, fill=(40, 36, 30))
    d.text((x + 12, y + ICON + 22), key, font=f_key, fill=(150, 143, 132))

img.save(BASE + r"\预览.png")
print(img.size)
