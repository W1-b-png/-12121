using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

// 这一块会被拼进 MousePet.cs：状态帧表 + 系统光标类型识别 + 覆盖层

class Frame
{
    public byte[] Data;      // 预乘后的 BGRA，已缩放到窗口尺寸
    public int HotX, HotY;   // 缩放后的热点
}

static class CursorKind
{
    const uint IDC_ARROW = 32512, IDC_IBEAM = 32513, IDC_WAIT = 32514, IDC_CROSS = 32515,
               IDC_UPARROW = 32516, IDC_SIZENWSE = 32642, IDC_SIZENESW = 32643,
               IDC_SIZEWE = 32644, IDC_SIZENS = 32645, IDC_SIZEALL = 32646,
               IDC_NO = 32648, IDC_HAND = 32649, IDC_APPSTARTING = 32650,
               IDC_HELP = 32651, IDC_PEN = 32631;

    static readonly uint[] Ids = { IDC_ARROW, IDC_IBEAM, IDC_WAIT, IDC_CROSS, IDC_UPARROW,
                                   IDC_SIZENWSE, IDC_SIZENESW, IDC_SIZEWE, IDC_SIZENS, IDC_SIZEALL,
                                   IDC_NO, IDC_HAND, IDC_APPSTARTING, IDC_HELP, IDC_PEN };

    static readonly string[] Keys = { "arrow", "ibeam", "wait", "crosshair", "uparrow",
                                      "sizenwse", "sizenesw", "sizewe", "sizens", "sizeall",
                                      "no", "hand", "appstarting", "help", "nwpen" };

    static IntPtr[] handles;
    public static bool Dirty = true;

    static void Load()
    {
        handles = new IntPtr[Ids.Length];
        for (int i = 0; i < Ids.Length; i++)
            handles[i] = Nat.LoadCursor(IntPtr.Zero, (IntPtr)Ids[i]);
        Dirty = false;
    }

    public static string Detect()
    {
        if (Dirty || handles == null) Load();

        Nat.CURSORINFO ci = new Nat.CURSORINFO();
        ci.cbSize = System.Runtime.InteropServices.Marshal.SizeOf(typeof(Nat.CURSORINFO));
        if (!Nat.GetCursorInfo(ref ci) || ci.hCursor == IntPtr.Zero) return "arrow";

        for (int i = 0; i < handles.Length; i++)
            if (handles[i] != IntPtr.Zero && handles[i] == ci.hCursor) return Keys[i];
        return "arrow";      // 应用自己加载的 .cur（如 Photoshop 画布）一律当箭头
    }
}

class Overlay : Form
{
    const int WS_EX_LAYERED = 0x80000;
    const int WS_EX_TRANSPARENT = 0x20;
    const int WS_EX_TOOLWINDOW = 0x80;
    const int WS_EX_NOACTIVATE = 0x08000000;
    const int CANVAS = 128;          // 内嵌帧的画布尺寸

    readonly Dictionary<string, Frame> frames = new Dictionary<string, Frame>();
    readonly Timer timer = new Timer();

    public bool FollowMode;

    IntPtr dib, oldObj, memDc, bits;
    int w, h;
    string shownKey;
    double animClock, lastMs, stateClock;
    int lastX, lastY;
    bool posed;

    public Overlay(bool follow)
    {
        FollowMode = follow;

        FormBorderStyle = FormBorderStyle.None;
        StartPosition = FormStartPosition.Manual;
        ShowInTaskbar = false;
        TopMost = true;
        Bounds = new Rectangle(0, 0, 1, 1);

        int cursorSize = Nat.GetSystemMetrics(Nat.SM_CXCURSOR);
        if (cursorSize <= 0) cursorSize = 32;

        // 角色约占画布的 76.5%，让它略大于系统光标
        int framePx = (int)Math.Round(cursorSize * 1.35 / 0.765);
        framePx = Math.Max(48, Math.Min(180, framePx));
        w = h = framePx;

        LoadPack();
        CreateSurface();

        Frame f0 = frames["arrow"];
        Draw(f0.Data, 0, 0);

        timer.Interval = 15;
        timer.Tick += Tick;
        timer.Start();
        lastMs = Now();
    }

    static double Now() { return DateTime.Now.Ticks / 10000.0; }

    protected override CreateParams CreateParams
    {
        get
        {
            CreateParams cp = base.CreateParams;
            cp.ExStyle |= WS_EX_LAYERED | WS_EX_TRANSPARENT | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE;
            return cp;
        }
    }

    protected override bool ShowWithoutActivation { get { return true; } }

    void LoadPack()
    {
        using (Stream s = Assembly.GetExecutingAssembly().GetManifestResourceStream("frames.bin"))
        using (BinaryReader r = new BinaryReader(s))
        {
            int n = r.ReadInt32();
            for (int i = 0; i < n; i++)
            {
                int len = r.ReadInt32();
                string name = Encoding.ASCII.GetString(r.ReadBytes(len));
                int hx = r.ReadInt32();
                int hy = r.ReadInt32();
                int dl = r.ReadInt32();
                byte[] png = r.ReadBytes(dl);
                frames[name] = Build(png, hx, hy);
            }
        }
    }

    Frame Build(byte[] png, int hx, int hy)
    {
        Frame f = new Frame();
        using (MemoryStream ms = new MemoryStream(png))
        using (Bitmap src = new Bitmap(ms))
        using (Bitmap scaled = new Bitmap(w, h, PixelFormat.Format32bppArgb))
        {
            using (Graphics g = Graphics.FromImage(scaled))
            {
                g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                g.PixelOffsetMode = PixelOffsetMode.HighQuality;
                g.Clear(Color.Transparent);
                g.DrawImage(src, new Rectangle(0, 0, w, h));
            }
            f.Data = Premultiplied(scaled);
        }
        double k = (double)w / CANVAS;
        f.HotX = (int)Math.Round(hx * k);
        f.HotY = (int)Math.Round(hy * k);
        return f;
    }

    static byte[] Premultiplied(Bitmap bmp)
    {
        BitmapData d = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height),
            ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
        int n = Math.Abs(d.Stride) * bmp.Height;
        byte[] buf = new byte[n];
        Marshal.Copy(d.Scan0, buf, 0, n);
        bmp.UnlockBits(d);
        for (int i = 0; i < n; i += 4)
        {
            int a = buf[i + 3];
            if (a == 255) continue;
            buf[i] = (byte)(buf[i] * a / 255);
            buf[i + 1] = (byte)(buf[i + 1] * a / 255);
            buf[i + 2] = (byte)(buf[i + 2] * a / 255);
        }
        return buf;
    }

    void CreateSurface()
    {
        Nat.BITMAPINFOHEADER bi = new Nat.BITMAPINFOHEADER();
        bi.biSize = 40; bi.biWidth = w; bi.biHeight = -h;
        bi.biPlanes = 1; bi.biBitCount = 32; bi.biCompression = 0;
        IntPtr screen = Nat.GetDC(IntPtr.Zero);
        dib = Nat.CreateDIBSection(screen, ref bi, 0, out bits, IntPtr.Zero, 0);
        memDc = Nat.CreateCompatibleDC(screen);
        oldObj = Nat.SelectObject(memDc, dib);
        Nat.ReleaseDC(IntPtr.Zero, screen);
    }

    void Draw(byte[] data, int x, int y)
    {
        Nat.POINT dst = new Nat.POINT();
        dst.X = x; dst.Y = y;
        Nat.POINT src = new Nat.POINT();
        Nat.SIZE sz = new Nat.SIZE(); sz.cx = w; sz.cy = h;
        Nat.BLENDFUNCTION blend = new Nat.BLENDFUNCTION();
        blend.BlendOp = 0; blend.BlendFlags = 0; blend.SourceConstantAlpha = 255;
        blend.AlphaFormat = Nat.AC_SRC_ALPHA;

        Marshal.Copy(data, 0, bits, data.Length);
        IntPtr screen = Nat.GetDC(IntPtr.Zero);
        Nat.UpdateLayeredWindow(Handle, screen, ref dst, ref sz, memDc, ref src, 0, ref blend, Nat.ULW_ALPHA);
        Nat.ReleaseDC(IntPtr.Zero, screen);
    }

    void Tick(object sender, EventArgs e)
    {
        double now = Now();
        double dt = Math.Max(1.0, now - lastMs);
        lastMs = now;
        stateClock += dt;

        Nat.POINT p;
        if (!Nat.GetCursorPos(out p)) return;
        if (!posed) { lastX = p.X; lastY = p.Y; posed = true; }

        double dx = p.X - lastX, dy = p.Y - lastY;
        double speed = Math.Sqrt(dx * dx + dy * dy) / dt;   // 像素/毫秒
        lastX = p.X; lastY = p.Y;

        string kind = CursorKind.Detect();
        string key;

        if (kind == "wait")
        {
            key = "wait" + ((int)(stateClock / 90) % 6);
        }
        else if (kind == "appstarting")
        {
            key = "app" + ((int)(stateClock / 80) % 12);
        }
        else if (kind == "arrow")
        {
            if (speed > 0.08)
            {
                animClock += dt * (0.6 + Math.Min(speed, 3.0) * 0.7);
                key = "run" + ((int)(animClock / 60.0) % 4);
            }
            else
            {
                key = "arrow";
            }
        }
        else
        {
            key = kind;
        }

        Frame f;
        if (!frames.TryGetValue(key, out f)) f = frames["arrow"];
        shownKey = key;

        int ox = FollowMode ? 26 : 0;
        int oy = FollowMode ? 30 : 0;
        Draw(f.Data, p.X - f.HotX + ox, p.Y - f.HotY + oy);
    }

    public void SetFollow(bool follow)
    {
        FollowMode = follow;
        posed = false;
        CursorKind.Dirty = true;
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            timer.Stop();
            if (memDc != IntPtr.Zero)
            {
                Nat.SelectObject(memDc, oldObj);
                Nat.DeleteDC(memDc);
                Nat.DeleteObject(dib);
                memDc = IntPtr.Zero;
            }
        }
        base.Dispose(disposing);
    }
}
