#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""png2cur.py —— 把一张 PNG 转成 Windows 光标 .cur（多尺寸、32 位阿尔法、带热点）

用法:
    python png2cur.py arrow.png                      # 默认尺寸 32,48,64,96，热点 (0,0)
    python png2cur.py arrow.png --hotspot 8,8        # 热点坐标按【原图】像素给出
    python png2cur.py arrow.png --sizes 32,48,64,96,128
    python png2cur.py a.png b.png --outdir out       # 批量

要点:
  * 原图建议 128 或 256 见方、透明背景，脚本用 LANCZOS 缩小，边缘更干净。
  * 一个 .cur 里装多个尺寸后，Windows 按 DPI / 光标大小自动挑最合适的一张。
  * .cur 格式里热点并不在像素数据里，而是存在目录项的 wPlanes / wBitCount
    两个字段中（微软自家的 aero_*.cur 就是这么存的），每个尺寸各存一份缩放后的值。
"""
from __future__ import annotations

import argparse
import glob
import struct
import sys
from pathlib import Path

from PIL import Image


def _dib_bytes(img: Image.Image) -> bytes:
    """生成 CUR 的图像块：BITMAPINFOHEADER + BGRA 位图（自下而上）+ AND 掩码。"""
    img = img.convert("RGBA")
    w, h = img.size
    flipped = img.transpose(Image.FLIP_TOP_BOTTOM)

    bgra = flipped.tobytes("raw", "BGRA")
    alpha = flipped.getchannel("A").tobytes()

    # AND 掩码：1 位/像素，1 = 透明，每行补齐到 4 字节
    row_bytes = ((w + 31) // 32) * 4
    mask = bytearray()
    for y in range(h):
        row = bytearray(row_bytes)
        for x in range(w):
            if alpha[y * w + x] == 0:
                row[x >> 3] |= 0x80 >> (x & 7)
        mask += row

    header = struct.pack(
        "<IiiHHIIiiII",
        40,            # biSize
        w,             # biWidth
        h * 2,         # biHeight = XOR 位图 + AND 掩码
        1,             # biPlanes
        32,            # biBitCount
        0,             # biCompression = BI_RGB
        len(bgra),     # biSizeImage
        0, 0, 0, 0,
    )
    return header + bgra + bytes(mask)


def png_to_cur(src: str | Path, dst: str | Path, *, hotspot=(0, 0),
               sizes=(32, 48, 64, 96)) -> Path:
    src, dst = Path(src), Path(dst)
    dst.parent.mkdir(parents=True, exist_ok=True)
    master = Image.open(src).convert("RGBA")
    mw, mh = master.size
    hx, hy = int(hotspot[0]), int(hotspot[1])

    blocks = []
    for size in sorted({int(s) for s in sizes}):
        size = max(8, min(256, size))
        frame = master.resize((size, size), Image.LANCZOS)
        sx = int(hx * size / mw + 0.5)
        sy = int(hy * size / mh + 0.5)
        sx = max(0, min(sx, size - 1))
        sy = max(0, min(sy, size - 1))
        blocks.append((size, sx, sy, _dib_bytes(frame)))

    offset = 6 + 16 * len(blocks)          # ICONDIR + 每个 ICONDIRENTRY
    entries, payload = b"", b""
    for size, sx, sy, data in blocks:
        dim = 0 if size >= 256 else size   # 0 表示 256
        # 目录项里的 wPlanes/wBitCount 在 .cur 中被用作热点坐标
        entries += struct.pack("<BBBBHHII", dim, dim, 0, 0, sx, sy, len(data), offset)
        payload += data
        offset += len(data)

    dst.write_bytes(struct.pack("<HHH", 0, 2, len(blocks)) + entries + payload)
    return dst


def main() -> int:
    ap = argparse.ArgumentParser(description="PNG -> Windows .cur（多尺寸 + 热点）")
    ap.add_argument("inputs", nargs="+", help="PNG 文件")
    ap.add_argument("-o", "--output", help="输出 .cur（仅单个输入时有效）")
    ap.add_argument("--outdir", default=".", help="批量输出目录，默认当前目录")
    ap.add_argument("--sizes", default="32,48,64,96", help="逗号分隔，默认 32,48,64,96")
    ap.add_argument("--hotspot", default="0,0", help="热点 x,y（按原图像素），默认 0,0")
    args = ap.parse_args()

    sizes = [int(s) for s in args.sizes.split(",") if s.strip()]
    try:
        hx, hy = (int(v) for v in args.hotspot.split(","))
    except ValueError:
        ap.error("--hotspot 需要形如 8,8")

    if args.output and len(args.inputs) > 1:
        ap.error("多输入时请用 --outdir")

    files: list[Path] = []
    for item in args.inputs:                       # 兼容 PowerShell 不展开通配符
        hits = sorted(glob.glob(item)) if any(c in item for c in "*?[") else []
        if hits:
            files.extend(Path(h) for h in hits)
        else:
            files.append(Path(item))

    for src in files:
        dst = Path(args.output) if args.output else Path(args.outdir) / (src.stem + ".cur")
        png_to_cur(src, dst, hotspot=(hx, hy), sizes=sizes)
        print(f"{src}  ->  {dst}  ({', '.join(map(str, sorted(sizes)))} px)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
